using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using HotelManagement.Data;
using HotelManagement.Models;
using System.Text.Json;
using Microsoft.AspNetCore.Http.Features;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });

builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = 10 * 1024 * 1024;
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp", policy =>
    {
        policy.WithOrigins("http://localhost:3000", "http://192.168.1.12:3000")
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials();
    });
});

builder.Services.AddAuthorization();
builder.Services.AddControllersWithViews();
builder.Services.AddSignalR();

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    });

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    context.Database.Migrate();

    if (!context.Roles.Any())
    {
        context.Roles.AddRange(
            new Role { Name = "guest" },
            new Role { Name = "hostess" },
            new Role { Name = "admin" }
        );
        context.SaveChanges();
    }

    if (!context.Users.Any(u => u.Login == "anna"))
    {
        var role = context.Roles.First(r => r.Name == "hostess");
        var hasher = new PasswordHasher<User>();
        var hostess = new User
        {
            Login = "anna",
            PasswordHash = hasher.HashPassword(null, "hostess123"),
            RoleId = role.RoleId,
            FirstName = "����",
            LastName = "�������",
            Email = "anna@hotel.com",
            Phone = "+79991234567"
        };
        context.Users.Add(hostess);
        context.SaveChanges();
    }

    if (!context.Rooms.Any())
    {
        context.Rooms.AddRange(
            new Room { RoomNumber = "101", RoomType = 1, Capacity = 2, PricePerNight = 2500, Description = "����������� �����", Status = 1 },
            new Room { RoomNumber = "102", RoomType = 1, Capacity = 2, PricePerNight = 2600, Description = "�������� � ����� �� ����", Status = 1 },
            new Room { RoomNumber = "201", RoomType = 2, Capacity = 3, PricePerNight = 4500, Description = "����", Status = 1 },
            new Room { RoomNumber = "301", RoomType = 3, Capacity = 4, PricePerNight = 6000, Description = "��������", Status = 1 }
        );
        context.SaveChanges();
    }

    if (!context.Users.Any(u => u.Login == "guest1"))
    {
        var guestRole = context.Roles.First(r => r.Name == "guest");
        var hasher = new PasswordHasher<User>();
        var guest = new User
        {
            Login = "guest1",
            PasswordHash = hasher.HashPassword(null, "guest123"),
            RoleId = guestRole.RoleId,
            FirstName = "����",
            LastName = "������",
            Email = "guest@hotel.com",
            Phone = "+79001234567"
        };
        context.Users.Add(guest);
        context.SaveChanges();

        var room = context.Rooms.First();
        var booking = new Booking
        {
            UserId = guest.UserId,
            RoomId = room.RoomId,
            CheckInDate = DateTime.Today.AddDays(1),
            CheckOutDate = DateTime.Today.AddDays(3),
            GuestsCount = 2,
            TotalPrice = 2 * room.PricePerNight,
            Status = 1
        };
        context.Bookings.Add(booking);
        context.SaveChanges();
    }
}

app.Use(async (context, next) =>
{
    try
    {
        await next();
    }
    catch (Exception ex)
    {
        Console.WriteLine($"���������� ������: {ex.Message}");
        Console.WriteLine(ex.StackTrace);
        context.Response.StatusCode = 500;
        await context.Response.WriteAsync("���������� ������ �������. �������� ����.");
    }
});

app.UseCors("AllowReactApp");
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(name: "default", pattern: "{controller=Account}/{action=Login}/{id?}");
app.MapControllers();
app.MapHub<HotelManagement.Hubs.NotificationHub>("/notificationHub");

app.Run();