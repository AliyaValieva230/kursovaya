﻿using System.ComponentModel.DataAnnotations;

namespace HotelManagement.Models
{
    public class RoomPhoto
    {
        [Key]
        public int PhotoId { get; set; }
        [Required, MaxLength(500)]
        public string FilePath { get; set; } = string.Empty;
        public int RoomId { get; set; }
        public Room Room { get; set; } = null!;
    }
}