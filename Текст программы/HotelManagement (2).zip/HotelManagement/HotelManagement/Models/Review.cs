﻿using System.ComponentModel.DataAnnotations;

namespace HotelManagement.Models
{
    public class Review
    {
        public int ReviewId { get; set; }
        [Range(1, 5)]
        public int Rating { get; set; }
        public string? Comment { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public int UserId { get; set; }
        public User User { get; set; } = null!;
        public int RoomId { get; set; }
        public Room Room { get; set; } = null!;
        public ICollection<ReviewPhoto> ReviewPhotos { get; set; } = new List<ReviewPhoto>();
    }
}