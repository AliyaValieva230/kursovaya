﻿namespace HotelManagement.Models
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
        public int Method { get; set; }
        public int Status { get; set; } = 1;
        public int BookingId { get; set; }
        public Booking Booking { get; set; } = null!;
    }
}