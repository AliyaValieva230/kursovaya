﻿using System.ComponentModel.DataAnnotations;

namespace HotelManagement.Models
{
    public class ReviewPhoto
    {
        [Key]
        public int ReviewPhotoId { get; set; }
        [Required, MaxLength(500)]
        public string FilePath { get; set; } = string.Empty;
        public int ReviewId { get; set; }
        public Review Review { get; set; } = null!;
    }
}