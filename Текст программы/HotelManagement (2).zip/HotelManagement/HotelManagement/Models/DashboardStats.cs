﻿namespace HotelManagement.Models
{
    public class DashboardStats
    {
        public int TotalBookingsToday { get; set; }
        public int AvailableRooms { get; set; }
        public int TotalGuests { get; set; }
        public decimal MonthlyRevenue { get; set; }
        public double OccupancyRate { get; set; }
    }
}