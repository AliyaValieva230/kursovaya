﻿namespace HotelManagement.Models
{
    public class BookingService
    {
        public int BookingServiceId { get; set; }
        public int Quantity { get; set; }
        public decimal PriceAtBooking { get; set; }
        public int BookingId { get; set; }
        public Booking Booking { get; set; } = null!;
        public int ServiceId { get; set; }
        public Service Service { get; set; } = null!;
    }
}