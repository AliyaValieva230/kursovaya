﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using HotelManagement.Data;
using HotelManagement.Models;
using System.Collections.Concurrent;

namespace HotelManagement.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class GuestController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly PasswordHasher<User> _passwordHasher;
        private static readonly ConcurrentDictionary<string, int> _tokens = new();

        public GuestController(ApplicationDbContext context)
        {
            _context = context;
            _passwordHasher = new PasswordHasher<User>();
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto model)
        {
            if (await _context.Users.AnyAsync(u => u.Login == model.Login))
                return BadRequest("Логин уже занят");

            var guestRole = await _context.Roles.FirstOrDefaultAsync(r => r.Name == "guest");
            if (guestRole == null) return BadRequest("Роль guest не найдена");

            var user = new User
            {
                Login = model.Login,
                PasswordHash = _passwordHasher.HashPassword(null, model.Password),
                RoleId = guestRole.RoleId,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Phone = model.Phone,
                RegisteredAt = DateTime.UtcNow
            };
            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            var token = Guid.NewGuid().ToString();
            _tokens[token] = user.UserId;
            return Ok(new { token, user = new { user.UserId, user.Login, user.FirstName, user.LastName, user.Email, user.Phone } });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto model)
        {
            var user = await _context.Users.Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.Login == model.Login);
            if (user == null || user.Role.Name != "guest")
                return Unauthorized("Неверный логин или пароль");

            var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, model.Password);
            if (result != PasswordVerificationResult.Success)
                return Unauthorized("Неверный логин или пароль");

            var token = Guid.NewGuid().ToString();
            _tokens[token] = user.UserId;
            return Ok(new { token, user = new { user.UserId, user.Login, user.FirstName, user.LastName, user.Email, user.Phone } });
        }

        private int? GetUserIdFromToken()
        {
            var token = Request.Headers["Authorization"].FirstOrDefault()?.Replace("Bearer ", "");
            if (token != null && _tokens.TryGetValue(token, out var userId))
                return userId;
            return null;
        }

        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound();
            return Ok(new { user.UserId, user.Login, user.FirstName, user.LastName, user.Email, user.Phone, user.RegisteredAt });
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileDto model)
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound();
            user.FirstName = model.FirstName ?? user.FirstName;
            user.LastName = model.LastName ?? user.LastName;
            user.Email = model.Email ?? user.Email;
            user.Phone = model.Phone ?? user.Phone;
            await _context.SaveChangesAsync();
            return Ok(new { user.UserId, user.Login, user.FirstName, user.LastName, user.Email, user.Phone });
        }

        [HttpGet("rooms")]
        public async Task<IActionResult> GetRooms([FromQuery] DateTime? checkIn, [FromQuery] DateTime? checkOut, [FromQuery] int? guests)
        {
            var query = _context.Rooms.Include(r => r.RoomPhotos).AsQueryable();
            if (checkIn.HasValue && checkOut.HasValue)
            {
                var bookedRoomIds = await _context.Bookings
                    .Where(b => b.Status == 1 || b.Status == 2)
                    .Where(b => !(b.CheckOutDate <= checkIn.Value || b.CheckInDate >= checkOut.Value))
                    .Select(b => b.RoomId)
                    .Distinct()
                    .ToListAsync();
                query = query.Where(r => !bookedRoomIds.Contains(r.RoomId));
            }
            if (guests.HasValue && guests.Value > 0)
                query = query.Where(r => r.Capacity >= guests.Value);
            var rooms = await query.ToListAsync();
            return Ok(rooms);
        }

        [HttpGet("rooms/{id}")]
        public async Task<IActionResult> GetRoomDetails(int id)
        {
            var room = await _context.Rooms
                .Include(r => r.RoomPhotos)
                .Include(r => r.Reviews)
                    .ThenInclude(rv => rv.ReviewPhotos)
                .Include(r => r.Reviews)
                    .ThenInclude(rv => rv.User)
                .FirstOrDefaultAsync(r => r.RoomId == id);
            if (room == null) return NotFound();
            return Ok(room);
        }

        [HttpPost("bookings")]
        public async Task<IActionResult> CreateBooking([FromBody] CreateBookingDto model)
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();

            var room = await _context.Rooms.FindAsync(model.RoomId);
            if (room == null) return BadRequest("Номер не найден");

            var nights = (model.CheckOutDate - model.CheckInDate).Days;
            decimal roomTotal = nights * room.PricePerNight;
            decimal servicesTotal = 0;
            var bookingServices = new List<BookingService>();

            if (model.Services != null)
            {
                foreach (var serviceDto in model.Services)
                {
                    var service = await _context.Services.FindAsync(serviceDto.ServiceId);
                    if (service != null)
                    {
                        servicesTotal += service.Price * serviceDto.Quantity;
                        bookingServices.Add(new BookingService
                        {
                            ServiceId = service.ServiceId,
                            Quantity = serviceDto.Quantity,
                            PriceAtBooking = service.Price
                        });
                    }
                }
            }

            var booking = new Booking
            {
                UserId = userId.Value,
                RoomId = model.RoomId,
                CheckInDate = model.CheckInDate,
                CheckOutDate = model.CheckOutDate,
                GuestsCount = model.GuestsCount,
                TotalPrice = roomTotal + servicesTotal,
                Status = 1,
                CreatedAt = DateTime.UtcNow,
                BookingServices = bookingServices
            };
            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();
            return Ok(booking);
        }

        [HttpGet("bookings/my")]
        public async Task<IActionResult> GetMyBookings()
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var bookings = await _context.Bookings
                .Include(b => b.Room)
                .Where(b => b.UserId == userId)
                .OrderByDescending(b => b.CreatedAt)
                .ToListAsync();
            return Ok(bookings);
        }

        [HttpGet("bookings/{id}")]
        public async Task<IActionResult> GetBookingById(int id)
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();

            var booking = await _context.Bookings
                .Include(b => b.Room)
                .Include(b => b.BookingServices)
                    .ThenInclude(bs => bs.Service)
                .FirstOrDefaultAsync(b => b.BookingId == id && b.UserId == userId);
            if (booking == null) return NotFound();
            return Ok(booking);
        }

        [HttpDelete("bookings/{id}")]
        public async Task<IActionResult> CancelBooking(int id)
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var booking = await _context.Bookings.FirstOrDefaultAsync(b => b.BookingId == id && b.UserId == userId);
            if (booking == null || booking.Status != 1) return BadRequest("Невозможно отменить");
            booking.Status = 3;
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("favorites")]
        public async Task<IActionResult> GetFavorites()
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var favorites = await _context.Favorites
                .Include(f => f.Room)
                .Where(f => f.UserId == userId)
                .ToListAsync();
            return Ok(favorites);
        }

        [HttpPost("favorites/{roomId}")]
        public async Task<IActionResult> AddFavorite(int roomId)
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            if (await _context.Favorites.AnyAsync(f => f.UserId == userId && f.RoomId == roomId))
                return BadRequest("Уже в избранном");
            var favorite = new Favorite { UserId = userId.Value, RoomId = roomId, AddedAt = DateTime.UtcNow };
            _context.Favorites.Add(favorite);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpDelete("favorites/{roomId}")]
        public async Task<IActionResult> RemoveFavorite(int roomId)
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var favorite = await _context.Favorites.FirstOrDefaultAsync(f => f.UserId == userId && f.RoomId == roomId);
            if (favorite != null)
            {
                _context.Favorites.Remove(favorite);
                await _context.SaveChangesAsync();
            }
            return Ok();
        }

        [HttpPost("reviews")]
        public async Task<IActionResult> AddReview([FromForm] CreateReviewDto model, List<IFormFile> photos)
        {
            try
            {
                var userId = GetUserIdFromToken();
                if (userId == null) return Unauthorized();

                var review = new Review
                {
                    RoomId = model.RoomId,
                    UserId = userId.Value,
                    Rating = model.Rating,
                    Comment = model.Comment,
                    CreatedAt = DateTime.UtcNow
                };
                _context.Reviews.Add(review);
                await _context.SaveChangesAsync();

                if (photos != null && photos.Any())
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "reviews");
                    if (!Directory.Exists(uploadsFolder))
                        Directory.CreateDirectory(uploadsFolder);

                    foreach (var photo in photos)
                    {
                        if (photo.Length > 0)
                        {
                            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(photo.FileName);
                            var filePath = Path.Combine(uploadsFolder, fileName);
                            using (var stream = new FileStream(filePath, FileMode.Create))
                                await photo.CopyToAsync(stream);
                            _context.ReviewPhotos.Add(new ReviewPhoto
                            {
                                FilePath = $"/images/reviews/{fileName}",
                                ReviewId = review.ReviewId
                            });
                        }
                    }
                    await _context.SaveChangesAsync();
                }
                return Ok(review);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при добавлении отзыва: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("reviews/my")]
        public async Task<IActionResult> GetMyReviews()
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var reviews = await _context.Reviews
                .Include(r => r.Room)
                .Include(r => r.ReviewPhotos)
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
            return Ok(reviews);
        }

        [HttpGet("services")]
        public async Task<IActionResult> GetServices()
        {
            var services = await _context.Services.ToListAsync();
            return Ok(services);
        }

        [HttpGet("payments")]
        public async Task<IActionResult> GetMyPayments()
        {
            var userId = GetUserIdFromToken();
            if (userId == null) return Unauthorized();
            var payments = await _context.Payments
                .Include(p => p.Booking)
                .ThenInclude(b => b.Room)
                .Where(p => p.Booking.UserId == userId)
                .ToListAsync();
            return Ok(payments);
        }
    }

    public class RegisterDto
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }

    public class LoginDto
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }

    public class UpdateProfileDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }

    public class CreateBookingDto
    {
        public int RoomId { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int GuestsCount { get; set; }
        public List<BookingServiceDto>? Services { get; set; }
    }

    public class BookingServiceDto
    {
        public int ServiceId { get; set; }
        public int Quantity { get; set; }
    }

    public class CreateReviewDto
    {
        public int RoomId { get; set; }
        public int Rating { get; set; }
        public string Comment { get; set; }
    }
}