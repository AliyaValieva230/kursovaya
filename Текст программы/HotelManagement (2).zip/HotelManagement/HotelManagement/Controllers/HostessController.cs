﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelManagement.Data;
using HotelManagement.Models;
using System.Security.Claims;
using System.Text;

namespace HotelManagement.Controllers
{
    [Authorize(Roles = "hostess")]
    public class HostessController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;

        public HostessController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        
        public async Task<IActionResult> Dashboard()
        {
            try
            {
                var today = DateTime.Today;
                var startOfMonth = new DateTime(today.Year, today.Month, 1);
                var stats = new DashboardStats
                {
                    TotalBookingsToday = await _context.Bookings.CountAsync(b => b.CheckInDate <= today && b.CheckOutDate >= today && b.Status == 2),
                    AvailableRooms = await _context.Rooms.CountAsync(r => r.Status == 1),
                    TotalGuests = await _context.Users.CountAsync(u => u.Role.Name == "guest"),
                    MonthlyRevenue = await _context.Bookings.Where(b => b.Status == 2 && b.CreatedAt >= startOfMonth).SumAsync(b => (decimal?)b.TotalPrice) ?? 0,
                    OccupancyRate = await GetOccupancyRate()
                };
                var recentBookings = await _context.Bookings.Include(b => b.User).Include(b => b.Room).OrderByDescending(b => b.CreatedAt).Take(10).ToListAsync();
                ViewBag.Stats = stats;
                ViewBag.RecentBookings = recentBookings;
                return View();
            }
            catch (Exception ex) { TempData["Error"] = ex.Message; return View(); }
        }

        private async Task<double> GetOccupancyRate()
        {
            var totalRooms = await _context.Rooms.CountAsync();
            if (totalRooms == 0) return 0;
            var today = DateTime.Today;
            var bookedRooms = await _context.Bookings.Where(b => b.Status == 2 && b.CheckInDate <= today && b.CheckOutDate >= today).Select(b => b.RoomId).Distinct().CountAsync();
            return (double)bookedRooms / totalRooms * 100;
        }

        
        public async Task<IActionResult> Bookings(string search, string status, string sort, int page = 1)
        {
            const int pageSize = 10;
            try
            {
                var query = _context.Bookings.Include(b => b.User).Include(b => b.Room).AsQueryable();

                // Поиск
                if (!string.IsNullOrEmpty(search))
                    query = query.Where(b => b.BookingId.ToString().Contains(search) ||
                                             b.User.FirstName.Contains(search) ||
                                             b.User.LastName.Contains(search) ||
                                             b.Room.RoomNumber.Contains(search));

                // Фильтр по статусу
                if (!string.IsNullOrEmpty(status) && int.TryParse(status, out int statusId))
                    query = query.Where(b => b.Status == statusId);

                // Сортировка
                query = sort switch
                {
                    "date_asc" => query.OrderBy(b => b.CheckInDate),
                    "date_desc" => query.OrderByDescending(b => b.CheckInDate),
                    "price_asc" => query.OrderBy(b => b.TotalPrice),
                    "price_desc" => query.OrderByDescending(b => b.TotalPrice),
                    "guest_asc" => query.OrderBy(b => b.User.LastName),
                    "guest_desc" => query.OrderByDescending(b => b.User.LastName),
                    "room_asc" => query.OrderBy(b => b.Room.RoomNumber),
                    "room_desc" => query.OrderByDescending(b => b.Room.RoomNumber),
                    _ => query.OrderByDescending(b => b.CreatedAt)
                };

                var totalItems = await query.CountAsync();
                var bookings = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

                ViewBag.CurrentSearch = search;
                ViewBag.CurrentStatus = status;
                ViewBag.CurrentSort = sort;
                ViewBag.CurrentPage = page;
                ViewBag.TotalPages = (int)Math.Ceiling(totalItems / (double)pageSize);

                return View(bookings);
            }
            catch (Exception ex) { TempData["Error"] = ex.Message; return RedirectToAction("Dashboard"); }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmBooking(int id)
        {
            var booking = await _context.Bookings.Include(b => b.BookingServices).FirstOrDefaultAsync(b => b.BookingId == id);
            if (booking != null && booking.Status == 1)
            {
                booking.Status = 2;
                var room = await _context.Rooms.FindAsync(booking.RoomId);
                if (room != null && room.Status == 1) room.Status = 2;
                var payment = new Payment { BookingId = booking.BookingId, Amount = booking.TotalPrice, PaymentDate = DateTime.UtcNow, Method = 2, Status = 2 };
                _context.Payments.Add(payment);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Бронирование подтверждено, оплата зарегистрирована.";
            }
            else TempData["Error"] = "Не удалось подтвердить бронирование.";
            return RedirectToAction("Bookings");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelBooking(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null && booking.Status == 1)
            {
                booking.Status = 3;
                var room = await _context.Rooms.FindAsync(booking.RoomId);
                if (room != null && room.Status == 2) room.Status = 1;
                await _context.SaveChangesAsync();
                TempData["Success"] = "Бронирование отменено.";
            }
            else TempData["Error"] = "Не удалось отменить бронирование.";
            return RedirectToAction("Bookings");
        }

        public async Task<IActionResult> ExportBookingsCsv()
        {
            var bookings = await _context.Bookings.Include(b => b.User).Include(b => b.Room).ToListAsync();
            var csv = new StringBuilder();
            csv.AppendLine("ID,Гость,Номер,Дата заезда,Дата выезда,Сумма,Статус");
            foreach (var b in bookings)
            {
                var statusText = b.Status == 1 ? "Новое" : b.Status == 2 ? "Подтверждено" : "Отменено";
                csv.AppendLine($"{b.BookingId},{EscapeCsv(b.User?.FirstName + " " + b.User?.LastName)},{b.Room?.RoomNumber},{b.CheckInDate:yyyy-MM-dd},{b.CheckOutDate:yyyy-MM-dd},{b.TotalPrice},{statusText}");
            }
            return File(Encoding.UTF8.GetBytes(csv.ToString()), "text/csv", $"bookings_{DateTime.Now:yyyyMMdd}.csv");
        }

        private string EscapeCsv(string? input)
        {
            if (string.IsNullOrEmpty(input)) return "";
            if (input.Contains(",") || input.Contains("\"") || input.Contains("\n"))
                return $"\"{input.Replace("\"", "\"\"")}\"";
            return input;
        }

        public async Task<IActionResult> BookingDetails(int id)
        {
            var booking = await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Room)
                .Include(b => b.BookingServices).ThenInclude(bs => bs.Service)
                .FirstOrDefaultAsync(b => b.BookingId == id);
            if (booking == null) return NotFound();
            ViewBag.Services = await _context.Services.ToListAsync();
            return View(booking);
        }

        
        public async Task<IActionResult> Guests(string search, string sort, int page = 1)
        {
            const int pageSize = 10;
            var query = _context.Users.Include(u => u.Role).Where(u => u.Role.Name == "guest").AsQueryable();

            if (!string.IsNullOrEmpty(search))
                query = query.Where(u => u.FirstName.Contains(search) || u.LastName.Contains(search) || u.Email.Contains(search) || u.Phone.Contains(search));

            query = sort switch
            {
                "name_asc" => query.OrderBy(u => u.LastName),
                "name_desc" => query.OrderByDescending(u => u.LastName),
                "date_asc" => query.OrderBy(u => u.RegisteredAt),
                "date_desc" => query.OrderByDescending(u => u.RegisteredAt),
                _ => query.OrderByDescending(u => u.RegisteredAt)
            };

            var total = await query.CountAsync();
            var guests = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

            ViewBag.Search = search;
            ViewBag.Sort = sort;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(total / (double)pageSize);
            return View(guests);
        }

        public async Task<IActionResult> GuestHistory(int id)
        {
            var guest = await _context.Users.FindAsync(id);
            if (guest == null) return NotFound();
            var bookings = await _context.Bookings.Include(b => b.Room).Where(b => b.UserId == id).OrderByDescending(b => b.CreatedAt).ToListAsync();
            ViewBag.Guest = guest;
            return View(bookings);
        }

        
        public async Task<IActionResult> Rooms(string search, int? type, int? status, int? minPrice, int? maxPrice, string sort, int page = 1)
        {
            const int pageSize = 10;
            var query = _context.Rooms.AsQueryable();

            // Поиск по номеру
            if (!string.IsNullOrEmpty(search))
                query = query.Where(r => r.RoomNumber.Contains(search));

            // Фильтр по типу
            if (type.HasValue)
                query = query.Where(r => r.RoomType == type.Value);

            // Фильтр по статусу
            if (status.HasValue)
                query = query.Where(r => r.Status == status.Value);

            // Фильтр по цене (ползунок)
            if (minPrice.HasValue)
                query = query.Where(r => r.PricePerNight >= minPrice.Value);
            if (maxPrice.HasValue)
                query = query.Where(r => r.PricePerNight <= maxPrice.Value);

            // Сортировка
            query = sort switch
            {
                "price_asc" => query.OrderBy(r => r.PricePerNight),
                "price_desc" => query.OrderByDescending(r => r.PricePerNight),
                "capacity_asc" => query.OrderBy(r => r.Capacity),
                "capacity_desc" => query.OrderByDescending(r => r.Capacity),
                "type_asc" => query.OrderBy(r => r.RoomType),
                "type_desc" => query.OrderByDescending(r => r.RoomType),
                "status_asc" => query.OrderBy(r => r.Status),
                "status_desc" => query.OrderByDescending(r => r.Status),
                _ => query.OrderBy(r => r.RoomNumber)
            };

            var totalItems = await query.CountAsync();
            var rooms = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

            ViewBag.Search = search;
            ViewBag.Type = type;
            ViewBag.Status = status;
            ViewBag.MinPrice = minPrice;
            ViewBag.MaxPrice = maxPrice;
            ViewBag.Sort = sort;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalItems / (double)pageSize);
            ViewBag.RoomTypes = GetRoomTypes();
            ViewBag.Statuses = GetRoomStatuses();
            ViewBag.MaxRoomPrice = await _context.Rooms.MaxAsync(r => r.PricePerNight); // для ползунка

            return View(rooms);
        }

        [HttpPost]
        public async Task<IActionResult> ChangeRoomStatus(int roomId, int status)
        {
            var room = await _context.Rooms.FindAsync(roomId);
            if (room != null) { room.Status = status; await _context.SaveChangesAsync(); TempData["Success"] = "Статус обновлён."; }
            else TempData["Error"] = "Номер не найден.";
            return RedirectToAction("Rooms");
        }

        [HttpGet]
        public async Task<IActionResult> EditRoom(int id)
        {
            var room = await _context.Rooms.FindAsync(id);
            if (room == null) return NotFound();
            return View(room);
        }

        [HttpPost]
        public async Task<IActionResult> EditRoom(Room room)
        {
            if (ModelState.IsValid)
            {
                try { _context.Rooms.Update(room); await _context.SaveChangesAsync(); TempData["Success"] = "Сохранено."; return RedirectToAction("Rooms"); }
                catch (Exception ex) { TempData["Error"] = ex.Message; }
            }
            return View(room);
        }

        [HttpGet]
        public IActionResult CreateRoom() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateRoom(Room room)
        {
            if (ModelState.IsValid)
            {
                if (await _context.Rooms.AnyAsync(r => r.RoomNumber == room.RoomNumber))
                {
                    ModelState.AddModelError("RoomNumber", "Номер комнаты уже существует");
                    return View(room);
                }
                _context.Rooms.Add(room);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Номер {room.RoomNumber} создан.";
                return RedirectToAction("Rooms");
            }
            return View(room);
        }

        [HttpGet]
        public async Task<IActionResult> DeleteRoom(int id)
        {
            var room = await _context.Rooms.FindAsync(id);
            if (room == null) return NotFound();
            return View(room);
        }

        [HttpPost, ActionName("DeleteRoom")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteRoomConfirmed(int id)
        {
            var room = await _context.Rooms
                .Include(r => r.RoomPhotos)
                .FirstOrDefaultAsync(r => r.RoomId == id);
            if (room == null) return NotFound();

            foreach (var photo in room.RoomPhotos)
            {
                var fullPath = Path.Combine(_env.WebRootPath, photo.FilePath.TrimStart('/'));
                if (System.IO.File.Exists(fullPath))
                    System.IO.File.Delete(fullPath);
            }

            _context.Rooms.Remove(room);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Номер {room.RoomNumber} удалён.";
            return RedirectToAction(nameof(Rooms));
        }

        
        [HttpGet]
        public async Task<IActionResult> RoomPhotos(int id)
        {
            var room = await _context.Rooms.Include(r => r.RoomPhotos).FirstOrDefaultAsync(r => r.RoomId == id);
            if (room == null) return NotFound();
            return View(room);
        }

        [HttpPost]
        public async Task<IActionResult> AddRoomPhoto(int roomId, IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0) { TempData["Error"] = "Файл не выбран."; return RedirectToAction("RoomPhotos", new { id = roomId }); }
                var room = await _context.Rooms.FindAsync(roomId);
                if (room == null) { TempData["Error"] = "Номер не найден."; return RedirectToAction("Rooms"); }
                var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "rooms");
                if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                var filePath = Path.Combine(uploadsFolder, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create)) await file.CopyToAsync(stream);
                var photo = new RoomPhoto { FilePath = $"/images/rooms/{fileName}", RoomId = roomId };
                _context.RoomPhotos.Add(photo);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Фото добавлено.";
            }
            catch (Exception ex) { TempData["Error"] = ex.Message; }
            return RedirectToAction("RoomPhotos", new { id = roomId });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteRoomPhoto(int photoId)
        {
            var photo = await _context.RoomPhotos.FindAsync(photoId);
            if (photo != null)
            {
                var fullPath = Path.Combine(_env.WebRootPath, photo.FilePath.TrimStart('/'));
                if (System.IO.File.Exists(fullPath)) System.IO.File.Delete(fullPath);
                _context.RoomPhotos.Remove(photo);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Фото удалено.";
            }
            else TempData["Error"] = "Фото не найдено.";
            return RedirectToAction("RoomPhotos", new { id = photo?.RoomId });
        }

        
        public async Task<IActionResult> Reviews()
        {
            var reviews = await _context.Reviews.Include(r => r.User).Include(r => r.Room).Include(r => r.ReviewPhotos).OrderByDescending(r => r.CreatedAt).ToListAsync();
            return View(reviews);
        }

        public async Task<IActionResult> RoomReviews(int id)
        {
            var room = await _context.Rooms.FindAsync(id);
            if (room == null) { TempData["Error"] = "Номер не найден."; return RedirectToAction("Rooms"); }
            var reviews = await _context.Reviews.Include(r => r.User).Include(r => r.ReviewPhotos).Where(r => r.RoomId == id).OrderByDescending(r => r.CreatedAt).ToListAsync();
            ViewBag.Room = room;
            return View(reviews);
        }

        [HttpPost]
        public async Task<IActionResult> CreateReview(int roomId, int rating, string comment, List<IFormFile> photos)
        {
            try
            {
                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var review = new Review { RoomId = roomId, UserId = userId, Rating = rating, Comment = comment, CreatedAt = DateTime.UtcNow };
                _context.Reviews.Add(review);
                await _context.SaveChangesAsync();
                if (photos != null && photos.Any())
                {
                    var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "reviews");
                    if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);
                    foreach (var file in photos)
                    {
                        if (file.Length > 0)
                        {
                            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                            var filePath = Path.Combine(uploadsFolder, fileName);
                            using (var stream = new FileStream(filePath, FileMode.Create)) await file.CopyToAsync(stream);
                            _context.ReviewPhotos.Add(new ReviewPhoto { FilePath = $"/images/reviews/{fileName}", ReviewId = review.ReviewId });
                        }
                    }
                    await _context.SaveChangesAsync();
                }
                TempData["Success"] = "Отзыв добавлен.";
            }
            catch (Exception ex) { TempData["Error"] = ex.Message; }
            return RedirectToAction("RoomReviews", new { id = roomId });
        }

        
        public async Task<IActionResult> Services()
        {
            var services = await _context.Services.ToListAsync();
            return View(services);
        }

        public async Task<IActionResult> Payments()
        {
            var payments = await _context.Payments.Include(p => p.Booking).ThenInclude(b => b.Room).ToListAsync();
            return View(payments);
        }

        
        public async Task<IActionResult> RevenueReport(DateTime? from, DateTime? to)
        {
            var endDate = (to ?? DateTime.Today).AddDays(1);
            var startDate = from ?? DateTime.Today.AddMonths(-1);
            var dailyRevenue = await _context.Bookings.Where(b => b.Status == 2 && b.CreatedAt >= startDate && b.CreatedAt < endDate).GroupBy(b => b.CreatedAt.Date).Select(g => new DailyRevenue { Date = g.Key, Total = g.Sum(b => b.TotalPrice) }).OrderBy(d => d.Date).ToListAsync();
            ViewBag.From = startDate;
            ViewBag.To = to ?? DateTime.Today;
            return View(dailyRevenue);
        }

        
        private IEnumerable<object> GetRoomTypes() => new[]
        {
            new { Value = 1, Name = "Стандарт" },
            new { Value = 2, Name = "Люкс" },
            new { Value = 3, Name = "Семейный" },
            new { Value = 4, Name = "Президентский" }
        };
        private IEnumerable<object> GetRoomStatuses() => new[]
        {
            new { Value = 1, Name = "Свободен" },
            new { Value = 2, Name = "Занят" },
            new { Value = 3, Name = "Уборка" },
            new { Value = 4, Name = "Ремонт" }
        };
    }

    public class DashboardStats
    {
        public int TotalBookingsToday { get; set; }
        public int AvailableRooms { get; set; }
        public int TotalGuests { get; set; }
        public decimal MonthlyRevenue { get; set; }
        public double OccupancyRate { get; set; }
    }

    public class DailyRevenue
    {
        public DateTime Date { get; set; }
        public decimal Total { get; set; }
    }
}