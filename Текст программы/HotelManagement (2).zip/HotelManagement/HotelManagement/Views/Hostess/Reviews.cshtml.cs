using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HotelManagement.Views.Hostess
{
    public class ReviewsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
