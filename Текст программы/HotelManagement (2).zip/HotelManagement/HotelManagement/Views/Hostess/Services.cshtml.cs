using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HotelManagement.Views.Hostess
{
    public class ServicesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
