using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HotelManagement.Views.Hostess
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
