using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HotelManagement.Views.Hostess
{
    public class DeleteRoomModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
