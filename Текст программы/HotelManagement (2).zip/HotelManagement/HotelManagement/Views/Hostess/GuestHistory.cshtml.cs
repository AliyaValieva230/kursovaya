using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HotelManagement.Views.Hostess
{
    public class GuestHistoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
