﻿using Microsoft.AspNetCore.Mvc;

namespace HotelManagement.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            if (User.Identity.IsAuthenticated && User.IsInRole("hostess"))
                return RedirectToAction("Dashboard", "Hostess");
            return RedirectToAction("Login", "Account");
        }
    }
}