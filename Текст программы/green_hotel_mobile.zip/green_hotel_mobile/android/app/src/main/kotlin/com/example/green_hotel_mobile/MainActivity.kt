package com.example.green_hotel_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
